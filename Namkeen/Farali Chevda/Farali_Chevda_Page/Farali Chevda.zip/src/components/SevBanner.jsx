export { default } from './FaraliBanner';
